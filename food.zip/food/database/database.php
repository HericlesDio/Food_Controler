<?php 
   
   $dbhost = array('local' => 'localhost', 'prod' => '');
   $dbuser = array('local' => 'httposiris', 'prod' => '');
   $dbpass = array('local' => 'linux', 'prod' => '');
   $dbname = array('local' => 'food', 'prod' => '');

   try {
       //code...
       $pdo = new PDO("mysql:host={$dbhost['local']};dbname={$dbname['local']}", $dbuser['local'], $dbpass['local']);
       
   } catch (PDOException $e) {
       //throw $th;
       echo "{$e->getMessage()}";
    
   }

?> 